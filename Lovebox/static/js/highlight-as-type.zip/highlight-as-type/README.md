filteringhighlight
==================

Simple jQuery plugin support highlight text which is typed in specifed <input> element.

Documentation
=============

Please visit http://wiki.aiwsolutions.net/EUgIm for demonstration and full guidelines
